/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reg.backend.utils;

/**
 *
 * @author duncan
 */
public enum REGISTERCODE{
    SUCCESS , DUPLICATE, GENERAL_ERROR, SESSION_EXPIRED, MORE, MORE2; 
}
